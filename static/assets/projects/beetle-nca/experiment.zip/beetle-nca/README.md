# Beetle NCA

An **8,336-parameter neural cellular automaton** trained to grow a beetle from one seed cell and recover from local damage. Each cell applies the same learned rule using only its state and its neighbors.

![Target, grown beetle, circular damage, and recovered pattern](results/media/comparison.png)

## Results

| Measure | Held-out result |
| --- | ---: |
| Growth at 384 recurrent updates | 16 / 16 trials passed |
| Recovery after local damage | 26 / 32 cases passed |
| Mean silhouette overlap (alpha IoU) | 0.8357 |
| Mean foreground RGBA MSE | 0.020522 |
| Stability at updates 512, 768, and 1,024 | 16 / 16 retained IoU ≥ 0.75 at each checkpoint |
| Training time / optimizer updates | 50.2 minutes / 3,000 |

Training used an RTX 4060 Laptop GPU with 8 GB VRAM. The animations show actual recurrent inference from the median held-out growth trial, seed `30012`, without target blending or automatic reseeding.

![Growth from one seed cell](results/media/growth.gif)

[Growth video](results/media/growth.mp4) · [Damage and repair video](results/media/regeneration.mp4) · [Training curve](results/media/training-curve.svg)

This is one target and one trained model. Six local repair cases failed. Silhouette overlap does not measure fine color detail, so the evaluation also records foreground RGBA error. Stability at the measured checkpoints does not establish indefinite stability.

The first held-out evaluation prompted further training. Its report is retained, and the final evaluation uses fresh seeds `30000–30015`. See the [final trial data](results/evaluation.json), [earlier round](results/evaluation-round-1.json), and [evaluation history](results/evaluation-history.json).

## Run it

Use Python 3.12 from the repository root:

```sh
python -m venv .venv
```

Activate with `.venv\Scripts\Activate.ps1` in PowerShell or `source .venv/bin/activate` in bash, then:

```sh
python -m pip install -r requirements.txt
python -m pytest tests -q
python -m nca evaluate --checkpoint checkpoints/best.pt --base-seed 30000 --device cpu --out runs/evaluation
```

CPU evaluation can take several minutes. The included results were measured on CUDA; small numerical differences across devices are possible. The [reproduction guide](docs/REPRODUCING.md) covers the original environment, preprocessing, training, resuming, rendering, and exporting.

## Model

The `96 × 96` grid holds premultiplied RGBA and 12 hidden channels. Perception concatenates each cell's state and Sobel gradients into 48 features. A pointwise `48 → 128 → 16` network predicts a residual update; each cell fires independently with probability `0.5`. A neighborhood alpha mask preserves living cells.

Training uses a pool of 1,024 states, fresh seeds, and partial damage. There are no pretrained NCA weights. See the [method and evaluation protocol](docs/METHOD.md) and [binary export contract](export/model.json).

## Files

```text
nca/                    Model, training, evaluation, rendering, and export CLI
tests/                  Numerical, checkpoint, damage, and export tests
assets/                 Source artwork and prepared training target
checkpoints/            Selected and earlier model, configuration, training log
export/                 Float32 weights and cross-implementation parity fixtures
results/                Evaluation reports and recorded media
docs/                   Method and reproduction instructions
.github/workflows/      CPU test workflow
requirements.txt        Direct dependencies for portable evaluation
requirements.lock.txt   Original Windows/CUDA package inventory
```

The selected inference checkpoint is `checkpoints/best.pt`. `model-2500.pt` supports the earlier evaluation round. The approximately 604 MB optimizer/pool resume checkpoint is excluded. Fresh runs write their own checkpoints under `runs/`; `best.pt` cannot resume training. Saved evaluation tensors and extra media variants can be regenerated with the documented commands.

## Reference

Based on [Growing Neural Cellular Automata](https://distill.pub/2020/growing-ca/) by Alexander Mordvintsev, Ettore Randazzo, Eyvind Niklasson, and Michael Levin (2020), with its [reference notebook](https://github.com/google-research/self-organising-systems/blob/master/notebooks/growing_ca.ipynb).

## License

This project is licensed under the [MIT License](LICENSE).
