# Method and evaluation

## Target preparation

The source `1,254 × 1,254` PNG is preserved byte-for-byte in `assets/original.png`. A soft foreground alpha mask uses channel maxima from 16–24/255. Premultiplied RGBA is area-resampled to `62 × 64` cells and centered in a `96 × 96` grid. The audit checks the limbs and red features; target metadata and arrays are in `assets/`.

## Learned update rule

Each cell has 16 float32 channels: premultiplied RGBA plus 12 hidden channels. The center seed has RGB zero and every remaining channel set to one. All other cells start at zero.

Perception concatenates the complete state, horizontal Sobel gradients, and vertical Sobel gradients. Sobel coefficients are divided by eight. Pointwise convolutions with biases implement `48 → 128 → 16`, with an intermediate ReLU. The output layer is initialized to zero. The rule has 8,336 trainable parameters.

Updates are residual, using an independent Bernoulli firing mask with probability 0.5. The same firing decision applies to all channels of a cell. A cell survives only when its `3 × 3` neighborhood contains alpha > 0.1 both before and after the candidate update. Boundaries are zero. Display clamping never changes the recurrent state.

## Training

Training uses Adam with learning rate 0.002, reduced to 0.0002 after 2,000 updates, and per-parameter gradient normalization. A pool of 1,024 states supports persistence. Each batch of eight contains a fresh seed and up to three partially damaged states. Four-state microbatches accumulate gradients for one optimizer update; unroll lengths range from 96–160 recurrent steps.

The run used seed 42 and stopped after 3,000 optimizer updates when validation acceptance passed. Cumulative training time was 3,009.25 seconds within a 7,200-second budget.

## Evaluation protocol

Checkpoint selection first uses four seeds starting at 10,000, then a separate 16-seed validation set starting at 12,000, including stability. The first held-out evaluation used seeds beginning at 20,000 and missed the repair target by one case. Training continued within the original budget. The final evaluation uses fresh seeds 30,000–30,015.

| Check | Acceptance |
| --- | --- |
| Growth | At least 13/16 trials with alpha IoU ≥ 0.80 at step 384 |
| Local repair | At least 26/32 cases with valid growth, 10–30% foreground erased, and ≥90% pre-damage IoU recovered within 384 more updates |
| Stability | At least 13 successful trials retain IoU ≥ 0.75 at steps 512, 768, and 1,024, with finite, nonempty states |
| Complete erasure | An entirely erased state remains empty |

Two local damage shapes—circle and rectangle—are applied to each growth trial. Damage clears all 16 channels. Repair streams are independently seeded. Half-erasure is reported separately as a stress test.

Silhouette IoU thresholds alpha at 0.5. Both whole-grid and foreground RGBA errors are recorded because overlap does not measure fine color fidelity. The illustrative run is the median held-out growth trial by IoU (upper middle of 16 sorted values), seed 30,012. The circular illustration removes 20.33% of grown foreground.

The model is evaluated at a finite set of times. Stability through 1,024 updates is not a guarantee of indefinite stability. One artwork and one training run do not establish generalization to other targets or damage distributions.

## Export contract

`export/model.json` defines the 33,344-byte little-endian float32 weight layout. Matrices use output-major row order. Perception order is **all state channels, all dx channels, all dy channels**. Fixtures use NCHW with x rightward and y downward.

A compatible renderer must compute the candidate state across the grid before the post-update neighborhood life mask, share one stochastic mask across a cell’s channel groups, use zero boundaries, and clear all channels when applying damage. `nca.export.numpy_step` is the independent reference implementation.

The original export parity check had a maximum absolute error of `8.940696716308594e-08` against PyTorch. The media files show recorded recurrent inference.

## Reference

Alexander Mordvintsev, Ettore Randazzo, Eyvind Niklasson, and Michael Levin. [Growing Neural Cellular Automata](https://distill.pub/2020/growing-ca/). Distill, 2020. [Reference notebook](https://github.com/google-research/self-organising-systems/blob/master/notebooks/growing_ca.ipynb).
