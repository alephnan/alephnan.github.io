# Reproduce the beetle NCA

Run all commands from the repository root with **Python 3.12**. Use `runs/` for generated work so the published evidence remains unchanged. The bundled `checkpoints/best.pt` is the selected model from optimizer update 3,000 and training seed 42.

## CPU evaluation and tests

Create an environment:

```sh
python -m venv .venv
```

Activate it:

```powershell
# Windows PowerShell
.venv\Scripts\Activate.ps1
```

```sh
# macOS / Linux
source .venv/bin/activate
```

Install the direct dependencies and run the tests:

```sh
python -m pip install -r requirements.txt
python -m pytest tests -q
```

On Windows or Linux, to explicitly choose the CPU-only PyTorch wheel, first run `python -m pip install torch==2.7.1 --index-url https://download.pytorch.org/whl/cpu`, then install `requirements.txt`.

Evaluate the selected checkpoint:

```sh
python -m nca evaluate --checkpoint checkpoints/best.pt --base-seed 30000 --device cpu --out runs/evaluation
```

CPU execution can be slow. Small floating-point differences are possible across devices and software versions; the included report records the original CUDA evaluation. Matching the environment and seeds provides a stronger reproduction basis, not a promise of identical results on every device.

## Recorded GPU environment

The original run used Windows, Python 3.12, PyTorch `2.7.1+cu126`, CUDA runtime 12.6, NVIDIA driver 566.14, and an RTX 4060 Laptop GPU with 8 GB VRAM. With an activated Python 3.12 environment:

```sh
python -m pip install torch==2.7.1+cu126 --index-url https://download.pytorch.org/whl/cu126
python -m pip install -r requirements.lock.txt --extra-index-url https://download.pytorch.org/whl/cu126
python -c "import torch; print(torch.cuda.is_available()); print(torch.cuda.get_device_name())"
```

`requirements.lock.txt` preserves the original full package inventory. `requirements.txt` contains the direct dependencies for a more portable CPU setup. Neither torchvision nor a system CUDA toolkit is required for this experiment. The wheel options are documented on the official [PyTorch previous versions page](https://pytorch.org/get-started/previous-versions/#v271).

## Train a fresh run

The prepared target is already included. To audit preprocessing independently:

```sh
python -m nca prepare assets/original.png --out runs/prepared
```

Start a short benchmark, then resume the **same run** within a cumulative two-hour active training budget:

```sh
python -m nca train --run-dir runs/new-training --max-steps 5 --skip-validation
python -m nca train --run-dir runs/new-training --resume runs/new-training/last.pt --max-minutes 120
```

Training defaults to CUDA and does not silently fall back to CPU. The budget includes active training, checkpoint selection, and retries. Installation and final evaluation/rendering are outside that budget. `--max-steps` is a cumulative optimizer-update limit; resuming restores the optimizer, pool, RNG state, and consumed time.

The original full `last.pt` is not shipped because it is approximately 604 MB. `best.pt` is an inference checkpoint; **do not use it as a resumable training checkpoint**. A new run produces its own full `last.pt` under `runs/`.

## Evaluate, export, and render a new run

```sh
python -m nca evaluate --checkpoint runs/new-training/best.pt --base-seed 30000 --out runs/new-results
python -m nca export --checkpoint runs/new-training/best.pt --out runs/new-export
python -m nca render --checkpoint runs/new-training/best.pt --run-dir runs/new-training --out runs/new-results
```

Run evaluation before rendering so the renderer can use its report to select the median held-out trial. When an evaluation informs further model refinement, reserve fresh seeds for the next evaluation.

To recreate outputs from the **included** checkpoint:

```sh
python -m nca evaluate --checkpoint checkpoints/best.pt --base-seed 30000 --device cpu --out runs/reproduced
python -m nca render --checkpoint checkpoints/best.pt --run-dir checkpoints --device cpu --out runs/reproduced
python -m nca export --checkpoint checkpoints/best.pt --out runs/export
```
