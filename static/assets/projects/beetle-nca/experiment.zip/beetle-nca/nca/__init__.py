"""A reproducible growing and regenerating neural cellular automaton."""

__version__ = "1.0.0"
