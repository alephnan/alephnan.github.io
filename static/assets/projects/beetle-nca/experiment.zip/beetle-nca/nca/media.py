from __future__ import annotations

import json
import os
from pathlib import Path

import imageio.v2 as imageio
import numpy as np
import torch
from PIL import Image

from .common import device_setup, labeled_panel, load_checkpoint, state_rgba, write_json
from .damage import damage_mask
from .model import NCA, make_seed
from .target import load_target


@torch.no_grad()
def simulation_frames(model, state, seeds, steps=384):
    generators = [np.random.default_rng(seed) for seed in seeds]
    frames = [(0, state_rgba(state))]
    h, w = state.shape[-2:]
    for block in range(0, steps, 32):
        count = min(32, steps - block)
        masks = np.stack([rng.random((count, 1, h, w), dtype=np.float32) < 0.5 for rng in generators], 1)
        masks = torch.from_numpy(masks).to(state.device)
        for index in range(count):
            state = model(state, masks[index])
            step = block + index + 1
            if step % 2 == 0 or step == steps:
                frames.append((step, state_rgba(state)))
    return state, frames


def write_animation(path, frames, fps=30):
    """Encode identical simulation frames into a video and a lighter GIF."""
    path = Path(path)
    gif_frames = []
    with imageio.get_writer(str(path.with_suffix(".mp4")), fps=fps, codec="libx264", quality=8, macro_block_size=2, pixelformat="yuv420p", ffmpeg_log_level="error") as writer:
        for index, frame in enumerate(frames):
            writer.append_data(np.asarray(frame))
            if index % 2 == 0:
                width = min(frame.width, 960)
                smaller = frame.resize((width, round(frame.height * width / frame.width)), Image.Resampling.NEAREST)
                gif_frames.append(smaller.quantize(colors=128, dither=Image.Dither.NONE))
    gif_frames[0].save(path.with_suffix(".gif"), save_all=True, append_images=gif_frames[1:], duration=round(2000 / fps), loop=0, optimize=False, disposal=2)
    return {"mp4": path.with_suffix(".mp4").name, "gif": path.with_suffix(".gif").name, "fps": fps}


def plot_training(run_dir, destination):
    os.environ.setdefault("MPLCONFIGDIR", str(Path(run_dir).resolve().parent / "matplotlib-cache"))
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    rows = [json.loads(line) for line in (Path(run_dir) / "training.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]
    if not rows:
        return
    x = np.array([row["total_updates"] for row in rows])
    losses = np.array([row["loss"] for row in rows])
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11, "figure.facecolor": "#101014", "axes.facecolor": "#101014", "text.color": "#e5e5e9", "axes.labelcolor": "#c9c9d2", "xtick.color": "#a5a5b4", "ytick.color": "#a5a5b4", "axes.edgecolor": "#444452"})
    fig, ax = plt.subplots(figsize=(10, 4.4), layout="constrained")
    ax.plot(x, losses, color="#d96063", alpha=0.20, linewidth=0.7, label="Per-update RGBA loss")
    window = min(50, len(losses))
    ax.plot(x[window-1:], np.convolve(losses, np.ones(window) / window, mode="valid"), color="#ff4249", linewidth=1.8, label=f"{window}-update mean")
    ax.set_yscale("log")
    ax.set_xlabel("Optimizer updates")
    ax.set_ylabel("Premultiplied RGBA mean squared error")
    ax.set_title("Learning to grow the beetle", loc="left", pad=16, fontsize=16)
    ax.grid(axis="y", alpha=0.12)
    ax.spines[["top", "right"]].set_visible(False)
    ax.legend(frameon=False, labelcolor="#c9c9d2")
    fig.savefig(Path(destination) / "training-curve.png", dpi=180)
    fig.savefig(Path(destination) / "training-curve.svg")
    plt.close(fig)


def write_results(destination, run_dir, animations):
    destination = Path(destination)
    report = json.loads((destination / "evaluation.json").read_text(encoding="utf-8"))
    summary = json.loads((Path(run_dir) / "run-summary.json").read_text(encoding="utf-8"))
    growth, repair = report.get("growth", {}), report.get("repair", {})
    passed = report["acceptance_passed"]
    title = "Acceptance targets passed" if passed else "Experimental result - regeneration acceptance incomplete"
    lines = ["# Beetle NCA: measured results", "", f"**{title}.**", "", "These animations show actual recurrent model inference. The selected example is the median held-out growth trial, chosen by silhouette overlap.", "", "| Check | Result | Target |", "|---|---:|---:|", f"| Growth at 384 updates | {growth.get('successes', 0)}/{growth.get('trials', 16)} | At least 13/16 at alpha IoU >= 0.80 |", f"| Local damage recovery | {repair.get('successes', 0)}/{repair.get('trials', 32)} | At least 26/32 |", f"| Stability through 1,024 updates | {'Pass' if report.get('stability', {}).get('passed') else 'Incomplete'} | At least 13 successful trials retain IoU >= 0.75 |", f"| Complete erasure stays empty | {report.get('complete_erasure_stays_empty', False)} | True |", "", f"Training used {summary['elapsed_seconds'] / 60:.1f} minutes of the 120-minute budget, across {summary['total_updates']:,} optimizer updates. Selected checkpoint: update {report['checkpoint_step']:,}, training seed {report['checkpoint_seed']}. Stop reason: {summary['stop_reason']}.", "", f"Mean held-out silhouette IoU: {np.mean(growth.get('iou', [0])):.4f}. Mean foreground RGBA MSE: {np.mean(growth.get('foreground_rgba_mse', [0])):.6f}.", "", "## Growth and repair", "", "![Growth from a single cell](growth.gif)", "", "[Growth video](growth.mp4) | [Damage and repair video](regeneration.mp4)", "", "![Target, growth, damage, repair](comparison.png)", "", "![Training curve](training-curve.png)", "", "## Interpretation", "", "A repair success requires successful initial growth, erasure of 10-30% of the grown foreground, and recovery to at least 90% of the pre-damage IoU within 384 further updates. Both circular and rectangular cuts are tested. Half-erasure results are stress tests and do not affect acceptance. Silhouette IoU measures shape, so the report also includes foreground color error and visual comparisons.", "", "All 16 held-out growth seeds are distinct from checkpoint-selection seeds. The 32 repair cases consist of two damage shapes applied to each grown trial. Stability is measured at steps 512, 768, and 1,024. No automatic reseeding or target-image blending is used during inference.", "", "See [evaluation.json](evaluation.json) for every trial, [animation metadata](animations.json) for the displayed masks, and [README](../README.md) for reproduction instructions.", ""]
    (destination / "RESULTS.md").write_text("\n".join(lines), encoding="utf-8")
    history_path = destination / "evaluation-history.json"
    if history_path.exists():
        history = json.loads(history_path.read_text(encoding="utf-8"))
        additions = ["", "## Evaluation history", "", "The first held-out evaluation prompted further training within the original two-hour budget. Its metrics are retained below; the final evaluation uses fresh seeds.", ""]
        for previous in history:
            additions.append(f"- Checkpoint {previous['checkpoint_step']:,}, seeds starting at {previous['base_seed']}: growth {previous['growth_successes']}/16, repair {previous['repair_successes']}/32. [Full report]({previous['report']}).")
        additions += ["", f"This report evaluates checkpoint {report['checkpoint_step']:,} on seeds {report['base_seed']} through {report['base_seed'] + 15}.", ""]
        with (destination / "RESULTS.md").open("a", encoding="utf-8") as stream:
            stream.write("\n".join(additions))


def render(checkpoint, target_path, destination, run_dir, device="cuda"):
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    device = device_setup(device)
    payload = load_checkpoint(checkpoint)
    model = NCA().to(device).eval()
    model.load_state_dict(payload["model"])
    target = load_target(target_path, device)
    target_image = target[0].permute(1, 2, 0).cpu().numpy()
    report_path = destination / "evaluation.json"
    trial = 0
    base_seed = 20000
    if report_path.exists():
        report = json.loads(report_path.read_text(encoding="utf-8"))
        base_seed = report.get("base_seed", 20000)
        values = report.get("growth", {}).get("iou", [0])
        trial = int(np.argsort(values)[len(values) // 2])
    selected_seed = base_seed + trial
    grown, growth_frames = simulation_frames(model, make_seed(1, 96, device), [selected_seed])
    growth_panels = [labeled_panel([target_image, values[0]], ["TARGET", "GROWING FROM ONE CELL"], footer=f"Step {step:03d} / 384  |  Seed {selected_seed}  |  8,336 learned parameters") for step, values in growth_frames]
    growth_panels += [growth_panels[-1]] * 45
    growth_info = write_animation(destination / "growth", growth_panels)
    del growth_panels, growth_frames
    grown_image = state_rgba(grown)[0]
    damaged = grown.repeat(2, 1, 1, 1)
    damage_info = []
    for index, kind in enumerate(["circle", "rectangle"]):
        rng = np.random.default_rng(base_seed + 1000 + trial + (100 if kind == "rectangle" else 0))
        mask, fraction = damage_mask((grown[0, 3] >= 0.5).cpu().numpy(), rng, kind)
        damaged[index, :, torch.from_numpy(mask).to(device)] = 0
        damage_info.append({"kind": kind, "fraction_erased": fraction, "mask": mask.tolist()})
    # Match the two independent repair streams used by the final evaluator.
    repair_seeds = [base_seed + 2000 + trial, base_seed + 2000 + 16 + trial]
    repaired, repair_frames = simulation_frames(model, damaged, repair_seeds)
    before = labeled_panel([target_image, grown_image, grown_image], ["TARGET", "CIRCLE: BEFORE CUT", "RECTANGLE: BEFORE CUT"], footer=f"Grown for 384 updates from seed {selected_seed}. Damage clears all 16 state channels.")
    panels = [before] * 30
    cut_images = state_rgba(damaged)
    cut_panel = labeled_panel([target_image, cut_images[0], cut_images[1]], ["TARGET", "CIRCULAR CUT", "RECTANGULAR CUT"], footer=f"Removed {damage_info[0]['fraction_erased']:.1%} / {damage_info[1]['fraction_erased']:.1%} of foreground. No reseeding.")
    panels += [cut_panel] * 30
    panels += [labeled_panel([target_image, values[0], values[1]], ["TARGET", "CIRCLE: REPAIR", "RECTANGLE: REPAIR"], footer=f"Repair step {step:03d} / 384  |  Seed {selected_seed}  |  Actual NCA inference") for step, values in repair_frames]
    panels += [panels[-1]] * 45
    repair_info = write_animation(destination / "regeneration", panels)
    panels[-1].save(destination / "repair-final.png")
    plot_training(run_dir, destination)
    info = {"selection": "median held-out growth IoU", "seed": selected_seed, "checkpoint_step": payload["step"], "growth": growth_info, "repair": repair_info, "damage": damage_info, "simulation_steps_per_video_frame": 2, "automatic_reseeding": False}
    write_json(destination / "animations.json", info)
    if report_path.exists():
        write_results(destination, run_dir, info)
    return {"growth": growth_info, "repair": repair_info, "seed": selected_seed}
