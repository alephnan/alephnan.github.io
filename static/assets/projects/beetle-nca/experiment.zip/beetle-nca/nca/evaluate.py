from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import torch

from .common import batch_metrics, device_setup, labeled_panel, load_checkpoint, state_rgba, write_json
from .damage import damage_mask
from .model import NCA, make_seed
from .target import load_target


@torch.no_grad()
def rollout(model, state, steps, generators, snapshots=None, start_step=0):
    """Independent, reproducible CPU RNG streams, transferred in small batches."""
    h, w = state.shape[-2:]
    completed = 0
    while completed < steps:
        count = min(32, steps - completed)
        masks = np.stack([g.random((count, 1, h, w), dtype=np.float32) < 0.5 for g in generators], axis=1)
        masks = torch.from_numpy(masks).to(state.device)
        for index in range(count):
            state = model(state, masks[index])
            number = start_step + completed + index + 1
            if snapshots is not None and number in snapshots:
                snapshots[number] = state.detach().cpu().clone()
        completed += count
    return state


def _numbers(metrics):
    result = {}
    for key, value in metrics.items():
        result[key] = [float(number) if np.isfinite(number) else None for number in value.detach().cpu().tolist()]
    return result


@torch.no_grad()
def evaluate_model(model, target, count=16, base_seed=20000, full=True):
    device = target.device
    generators = [np.random.default_rng(base_seed + index) for index in range(count)]
    grown = rollout(model, make_seed(count, target.shape[-1], device), 384, generators)
    if not torch.isfinite(grown).all() or not torch.isfinite((grown[:, :4] - target).square()).all():
        return {"acceptance_passed": False, "score": -1.0, "error": "Non-finite state or squared error during growth", "base_seed": base_seed}, None
    growth = _numbers(batch_metrics(grown, target))
    growth_ok = np.asarray(growth["iou"]) >= 0.80
    rows = []
    damage_states = []
    masks = []
    for kind in ["circle", "rectangle"]:
        for index in range(count):
            foreground = (grown[index, 3] >= 0.5).cpu().numpy()
            rng = np.random.default_rng(base_seed + 1000 + index + (100 if kind == "rectangle" else 0))
            mask, fraction = damage_mask(foreground, rng, kind)
            damaged = grown[index].clone()
            damaged[:, torch.from_numpy(mask).to(device)] = 0
            damage_states.append(damaged)
            masks.append(mask)
            rows.append({"kind": kind, "seed": base_seed + index, "fraction_erased": fraction, "pre_damage_iou": growth["iou"][index]})
    damaged = torch.stack(damage_states)
    before_repair = _numbers(batch_metrics(damaged, target))
    repair_generators = [np.random.default_rng(base_seed + 2000 + i) for i in range(count * 2)]
    repaired = rollout(model, damaged, 384, repair_generators)
    if not torch.isfinite(repaired).all() or not torch.isfinite((repaired[:, :4] - target).square()).all():
        return {"acceptance_passed": False, "score": -1.0, "error": "Non-finite state or squared error during repair", "base_seed": base_seed}, None
    repair_metrics = _numbers(batch_metrics(repaired, target))
    for i, row in enumerate(rows):
        row.update({"damaged_iou": before_repair["iou"][i], "repaired_iou": repair_metrics["iou"][i], "repaired_rgba_mse": repair_metrics["rgba_mse"][i]})
        row["relative_recovery"] = row["repaired_iou"] / row["pre_damage_iou"] if row["pre_damage_iou"] > 0 else None
        row["recovered_grown_pattern"] = bool(0.10 <= row["fraction_erased"] <= 0.30 and row["pre_damage_iou"] > 0 and row["repaired_iou"] >= 0.9 * row["pre_damage_iou"])
        row["success"] = bool(0.10 <= row["fraction_erased"] <= 0.30 and row["pre_damage_iou"] >= 0.80 and row["repaired_iou"] >= 0.9 * row["pre_damage_iou"])
    report = {
        "base_seed": base_seed,
        "growth": {"steps": 384, "trials": count, "successes": int(growth_ok.sum()), "required": math.ceil(count * 13 / 16), "threshold_iou": 0.80, **growth},
        "repair": {"steps_after_damage": 384, "trials": count * 2, "successes": sum(row["success"] for row in rows), "recovered_grown_pattern_cases": sum(row["recovered_grown_pattern"] for row in rows), "required": math.ceil(count * 2 * 0.80), "requires_successful_initial_growth": True, "cases": rows},
    }
    stability_ok = True
    snapshots = None
    half_result = None
    if full:
        snapshots = {512: None, 768: None, 1024: None}
        stable = rollout(model, grown, 640, generators, snapshots=snapshots, start_step=384)
        stability_rows = []
        for step, state in snapshots.items():
            values = _numbers(batch_metrics(state.to(device), target))
            finite = bool(torch.isfinite(state).all())
            nonempty = (state[:, 3].flatten(1).max(1).values > 0.1).numpy()
            retained = (np.asarray(values["iou"]) >= 0.75) & growth_ok & nonempty
            stability_ok = stability_ok and finite and int(retained.sum()) >= math.ceil(count * 13 / 16)
            stability_rows.append({"step": step, "finite": finite, "nonempty_trials": int(nonempty.sum()), "retained_trials": int(retained.sum()), **values})
        report["stability"] = {"steps": 1024, "passed": stability_ok, "checkpoints": stability_rows}
        chosen = int(np.argsort(growth["iou"])[count // 2])
        half = grown[chosen:chosen + 1].repeat(2, 1, 1, 1)
        half[0, :, :, :target.shape[-1] // 2] = 0
        half[1, :, :target.shape[-1] // 2, :] = 0
        half_result = rollout(model, half, 384, [np.random.default_rng(base_seed + 5000 + i) for i in range(2)])
        report["half_erasure_stress"] = {"selection": "median growth IoU trial", "seed": base_seed + chosen, "cuts": ["left half", "top half"], **_numbers(batch_metrics(half_result, target)), "included_in_acceptance": False}
        empty = rollout(model, torch.zeros_like(grown[:1]), 32, [np.random.default_rng(base_seed + 6000)])
        report["complete_erasure_stays_empty"] = bool(torch.count_nonzero(empty).item() == 0)
        stability_ok = stability_ok and report["complete_erasure_stays_empty"]
    report["acceptance_passed"] = bool(report["growth"]["successes"] >= report["growth"]["required"] and report["repair"]["successes"] >= report["repair"]["required"] and stability_ok)
    report["score"] = float(np.mean(growth["iou"]) * 0.6 + np.mean(repair_metrics["iou"]) * 0.4)
    report["evaluation_type"] = "held-out final evaluation" if full and base_seed == 20000 else "checkpoint selection validation"
    tensors = {"grown": grown.cpu(), "damaged": damaged.cpu(), "repaired": repaired.cpu(), "snapshots": snapshots, "half_repaired": half_result.cpu() if half_result is not None else None}
    return report, tensors


def evaluate(checkpoint, target_path, destination, device="cuda", base_seed=20000):
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    device = device_setup(device)
    payload = load_checkpoint(checkpoint)
    model = NCA().to(device)
    model.load_state_dict(payload["model"])
    model.eval()
    target = load_target(target_path, device)
    report, tensors = evaluate_model(model, target, base_seed=base_seed)
    report["evaluation_type"] = "held-out evaluation"
    report.update({"checkpoint_step": payload["step"], "checkpoint_seed": payload["config"]["seed"], "training_budget_seconds_used_at_checkpoint": payload.get("elapsed_seconds"), "parameters": sum(p.numel() for p in model.parameters())})
    write_json(destination / "evaluation.json", report)
    if tensors is not None:
        arrays = {k: v.numpy() for k, v in tensors.items() if isinstance(v, torch.Tensor)}
        np.savez_compressed(destination / "evaluation-states.npz", **arrays)
        order = np.argsort(report["growth"]["iou"])
        index = int(order[len(order) // 2])
        images = [target[0].permute(1, 2, 0).cpu().numpy(), state_rgba(tensors["grown"])[index], state_rgba(tensors["damaged"])[index], state_rgba(tensors["repaired"])[index]]
        labeled_panel(images, ["TARGET", "GROWN / 384 STEPS", "CIRCULAR DAMAGE", "REPAIRED / +384"], footer=f"Median growth trial, seed {base_seed + index}. Actual model inference.").save(destination / "comparison.png")
    return report
