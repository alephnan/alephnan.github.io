from __future__ import annotations

import numpy as np


def damage_mask(foreground, rng, kind="circle", low=0.10, high=0.30):
    """Erase a local shape while keeping a nonempty surviving foreground."""
    foreground = np.asarray(foreground, dtype=bool)
    h, w = foreground.shape
    yy, xx = np.ogrid[:h, :w]
    positions = np.argwhere(foreground)
    count = len(positions)
    empty = np.zeros((h, w), dtype=bool)
    if count < 5:
        return empty, 0.0
    desired = float(rng.uniform(low, high))
    best, best_fraction, best_distance = empty, 0.0, float("inf")
    for _ in range(48):
        cy, cx = positions[int(rng.integers(count))]
        radius = np.sqrt(desired * count / np.pi) * rng.uniform(0.75, 2.3)
        if kind == "circle":
            erased = (xx - cx) ** 2 + (yy - cy) ** 2 <= radius ** 2
        elif kind == "rectangle":
            aspect = rng.uniform(0.6, 1.6)
            erased = (np.abs(xx - cx) <= radius * aspect) & (np.abs(yy - cy) <= radius / aspect)
        else:
            raise ValueError(f"Unknown damage kind: {kind}")
        fraction = float((erased & foreground).sum() / count)
        if 0 < fraction < 1 and abs(fraction - desired) < best_distance:
            best, best_fraction, best_distance = erased, fraction, abs(fraction - desired)
        if low <= fraction <= high:
            return erased, fraction
    return best, best_fraction
