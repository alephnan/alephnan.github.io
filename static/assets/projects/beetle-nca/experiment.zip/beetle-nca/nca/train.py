from __future__ import annotations

import csv
import hashlib
import json
import random
import time
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np
import torch

from .common import atomic_checkpoint, device_setup, labeled_panel, load_checkpoint, state_rgba, write_json
from .damage import damage_mask
from .evaluate import evaluate_model
from .model import NCA, make_seed
from .target import load_target


@dataclass
class TrainConfig:
    seed: int = 42
    channels: int = 16
    hidden: int = 128
    grid_size: int = 96
    pool_size: int = 1024
    batch_size: int = 8
    microbatch: int = 4
    damage_count: int = 3
    steps_min: int = 96
    steps_max: int = 160
    learning_rate: float = 0.002
    decay_at: int = 2000
    checkpoint_every: int = 250
    max_seconds: float = 7200.0


def seed_all(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def capture_rng(rng):
    return {"python": random.getstate(), "numpy_legacy": np.random.get_state(), "numpy_generator": rng.bit_generator.state, "torch_cpu": torch.get_rng_state(), "torch_cuda": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else []}


def restore_rng(saved, rng):
    random.setstate(saved["python"])
    np.random.set_state(saved["numpy_legacy"])
    rng.bit_generator.state = saved["numpy_generator"]
    torch.set_rng_state(saved["torch_cpu"])
    if torch.cuda.is_available() and saved["torch_cuda"]:
        torch.cuda.set_rng_state_all(saved["torch_cuda"])


def normalize_gradients(model):
    finite = True
    for parameter in model.parameters():
        if parameter.grad is None:
            continue
        norm = torch.linalg.vector_norm(parameter.grad)
        finite = finite and bool(torch.isfinite(norm))
        parameter.grad.div_(norm + 1e-8)
    return finite


def state_dict_cpu(model):
    return {key: value.detach().cpu() for key, value in model.state_dict().items()}


class TrainingFailure(RuntimeError):
    pass


def train(target_path, run_dir, resume=None, device="cuda", max_minutes=120, max_steps=None, validate=True):
    run_dir = Path(run_dir)
    run_dir.mkdir(parents=True, exist_ok=True)
    device = device_setup(device)
    target = load_target(target_path, device)
    target_cpu = target.cpu()
    target_hash = hashlib.sha256(Path(target_path).read_bytes()).hexdigest()
    cfg = TrainConfig(max_seconds=max_minutes * 60)
    elapsed_before = 0.0
    step = total_updates = 0
    best_score = -1.0
    restarts = []
    extinction_streak = 0
    history = []

    if resume:
        saved = load_checkpoint(resume)
        if saved["target_sha256"] != target_hash:
            raise ValueError("Resume target differs from the target used by the checkpoint.")
        cfg = TrainConfig(**saved["config"])
        cfg.max_seconds = max_minutes * 60
        elapsed_before = saved["elapsed_seconds"]
        step, total_updates = saved["step"], saved.get("total_updates", saved["step"])
        best_score = saved.get("best_score", -1.0)
        restarts = saved.get("restarts", [])
        extinction_streak = saved.get("extinction_streak", 0)
        history = saved.get("history", [])
    else:
        saved = None
    seed_all(cfg.seed)
    rng = np.random.default_rng(cfg.seed)
    model = NCA().to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=cfg.learning_rate)
    if saved is None:
        pool = make_seed(cfg.pool_size, cfg.grid_size)
    else:
        model.load_state_dict(saved["model"])
        optimizer.load_state_dict(saved["optimizer"])
        pool = saved["pool"]
        restore_rng(saved["rng"], rng)
        del saved
    if sum(p.numel() for p in model.parameters()) != 8336:
        raise AssertionError("Unexpected architecture parameter count")
    write_json(run_dir / "config.json", asdict(cfg))
    run_start = time.monotonic()
    last_step_seconds = 1.0
    validation_seconds_hint = 45.0
    benchmark_times = []
    completed_validation = None
    stop_reason = "training budget reached"

    def elapsed():
        return elapsed_before + time.monotonic() - run_start

    def payload(full):
        result = {"format_version": 1, "model": state_dict_cpu(model), "config": asdict(cfg), "step": step, "total_updates": total_updates, "elapsed_seconds": elapsed(), "target_sha256": target_hash, "best_score": best_score, "restarts": restarts, "validation": completed_validation}
        if full:
            result.update({"optimizer": optimizer.state_dict(), "pool": pool, "rng": capture_rng(rng), "history": history, "extinction_streak": extinction_streak})
        return result

    def save_last():
        atomic_checkpoint(run_dir / "last.pt", payload(True))

    def validate_checkpoint():
        nonlocal best_score, completed_validation, validation_seconds_hint
        start = time.monotonic()
        print(json.dumps({"event": "validation_started", "step": step, "elapsed_seconds": round(elapsed(), 1)}), flush=True)
        model.eval()
        report, tensors = evaluate_model(model, target, count=4, base_seed=10000, full=False)
        model.train()
        validation_seconds_hint = max(10.0, (time.monotonic() - start) * 1.3)
        completed_validation = report
        if report["score"] > best_score:
            best_score = report["score"]
            atomic_checkpoint(run_dir / "best.pt", payload(False))
            write_json(run_dir / "best-validation.json", report)
        write_json(run_dir / "latest-validation.json", report)
        if tensors is not None:
            images = [target_cpu[0].permute(1, 2, 0).numpy(), *state_rgba(tensors["grown"])]
            labeled_panel(images, ["TARGET", "SEED 10000", "SEED 10001", "SEED 10002", "SEED 10003"], footer=f"Validation after {step} optimizer updates; mean IoU {np.mean(report['growth']['iou']):.3f}", cell_scale=3).save(run_dir / "latest-validation.png")
        print(json.dumps({"event": "validation", "step": step, "score": report["score"], "growth_successes": report.get("growth", {}).get("successes", 0), "repair_successes": report.get("repair", {}).get("successes", 0), "elapsed_seconds": round(elapsed(), 1)}), flush=True)
        return report["acceptance_passed"]

    log_path = run_dir / "training.jsonl"
    try:
        with log_path.open("a", encoding="utf-8") as log:
            while elapsed() + max(5.0, last_step_seconds * 1.3) < cfg.max_seconds:
                if max_steps is not None and total_updates >= max_steps:
                    stop_reason = "requested benchmark/update limit reached"
                    break
                try:
                    started = time.monotonic()
                    indices = rng.choice(cfg.pool_size, cfg.batch_size, replace=False)
                    batch = pool[indices].clone()
                    losses = ((batch[:, :4] - target_cpu) ** 2).mean((1, 2, 3))
                    batch = batch[torch.argsort(losses, descending=True)]
                    batch[0] = make_seed(1, cfg.grid_size)[0]
                    for index in range(cfg.batch_size - cfg.damage_count, cfg.batch_size):
                        mask, fraction = damage_mask(batch[index, 3].numpy() >= 0.5, rng)
                        if fraction > 0:
                            batch[index, :, torch.from_numpy(mask)] = 0
                    unroll_steps = int(rng.integers(cfg.steps_min, cfg.steps_max + 1))
                    for group in optimizer.param_groups:
                        group["lr"] = cfg.learning_rate * (0.1 if step >= cfg.decay_at else 1)
                    rng_before_forward = capture_rng(rng)
                    while True:
                        optimizer.zero_grad(set_to_none=True)
                        outputs, loss_value = [], 0.0
                        try:
                            for start_index in range(0, cfg.batch_size, cfg.microbatch):
                                state = batch[start_index:start_index + cfg.microbatch].to(device)
                                for _ in range(unroll_steps):
                                    state = model(state)
                                loss = ((state[:, :4] - target) ** 2).mean((1, 2, 3)).sum() / cfg.batch_size
                                loss.backward()
                                loss_value += float(loss.detach())
                                outputs.append(state.detach().cpu())
                                del state, loss
                            break
                        except torch.OutOfMemoryError:
                            if cfg.microbatch == 1:
                                raise
                            cfg.microbatch //= 2
                            optimizer.zero_grad(set_to_none=True)
                            outputs.clear()
                            if "state" in locals():
                                del state
                            if "loss" in locals():
                                del loss
                            torch.cuda.empty_cache()
                            restore_rng(rng_before_forward, rng)
                            print(json.dumps({"event": "microbatch_reduced", "microbatch": cfg.microbatch}), flush=True)
                    if not np.isfinite(loss_value) or not normalize_gradients(model):
                        raise TrainingFailure("non-finite loss or gradients")
                    optimizer.step()
                    output_batch = torch.cat(outputs)
                    if not torch.isfinite(output_batch).all():
                        raise TrainingFailure("non-finite recurrent states")
                    pool[indices] = output_batch
                    extinction_streak = extinction_streak + 1 if not (output_batch[:, 3] > 0.1).any() else 0
                    if extinction_streak >= 30:
                        raise TrainingFailure("complete extinction for 30 consecutive updates")
                    step += 1
                    total_updates += 1
                    last_step_seconds = time.monotonic() - started
                    row = {"step": step, "total_updates": total_updates, "seed": cfg.seed, "loss": loss_value, "unroll_steps": unroll_steps, "seconds": last_step_seconds, "elapsed_seconds": elapsed(), "learning_rate": optimizer.param_groups[0]["lr"], "microbatch": cfg.microbatch}
                    history.append(row)
                    log.write(json.dumps(row) + "\n")
                    log.flush()
                    if total_updates <= 5 or total_updates % 10 == 0:
                        print(json.dumps({"event": "training", **{key: round(value, 5) if isinstance(value, float) else value for key, value in row.items()}}), flush=True)
                    if len(benchmark_times) < 5:
                        benchmark_times.append(last_step_seconds)
                        if len(benchmark_times) == 5:
                            benchmark = {"device": torch.cuda.get_device_name(device) if device.type == "cuda" else "CPU", "torch": torch.__version__, "cuda_runtime": torch.version.cuda, "parameters": 8336, "microbatch": cfg.microbatch, "effective_batch": cfg.batch_size, "unroll_range": [cfg.steps_min, cfg.steps_max], "optimizer_step_seconds": benchmark_times, "median_seconds_excluding_first": float(np.median(benchmark_times[1:])), "peak_allocated_gpu_gib": torch.cuda.max_memory_allocated(device) / 2**30 if device.type == "cuda" else None}
                            write_json(run_dir / "benchmark.json", benchmark)
                            print(json.dumps({"event": "benchmark", **benchmark}), flush=True)
                    if step % cfg.checkpoint_every == 0:
                        if validate and elapsed() + validation_seconds_hint + 10 < cfg.max_seconds:
                            passed = validate_checkpoint()
                            if passed and elapsed() + validation_seconds_hint * 5 + 10 < cfg.max_seconds:
                                # Separate 16-seed validation gate; final evaluation uses unseen seeds.
                                full_report, _ = evaluate_model(model, target, count=16, base_seed=12000, full=True)
                                write_json(run_dir / "acceptance-validation.json", full_report)
                                if full_report["acceptance_passed"]:
                                    completed_validation = full_report
                                    best_score = max(best_score, full_report["score"])
                                    atomic_checkpoint(run_dir / "best.pt", payload(False))
                                    stop_reason = "validation acceptance targets passed"
                                    save_last()
                                    break
                        save_last()
                except TrainingFailure as error:
                    if cfg.seed != 42:
                        stop_reason = f"restart also failed: {error}"
                        break
                    restarts.append({"from_seed": 42, "to_seed": 43, "reason": str(error), "elapsed_seconds": elapsed(), "step": step})
                    cfg.seed = 43
                    seed_all(cfg.seed)
                    rng = np.random.default_rng(cfg.seed)
                    model = NCA().to(device)
                    optimizer = torch.optim.Adam(model.parameters(), lr=cfg.learning_rate)
                    pool = make_seed(cfg.pool_size, cfg.grid_size)
                    step, extinction_streak = 0, 0
                    print(json.dumps({"event": "restart", **restarts[-1]}), flush=True)
    except KeyboardInterrupt:
        stop_reason = "interrupted; resumable checkpoint saved"
    if validate and elapsed() + validation_seconds_hint + 10 < cfg.max_seconds and step % cfg.checkpoint_every:
        validate_checkpoint()
    if not (run_dir / "best.pt").exists():
        atomic_checkpoint(run_dir / "best.pt", payload(False))
    save_last()
    write_json(run_dir / "run-summary.json", {"stop_reason": stop_reason, "step": step, "total_updates": total_updates, "seed": cfg.seed, "elapsed_seconds": elapsed(), "budget_seconds": cfg.max_seconds, "best_validation_score": best_score, "restarts": restarts})
    if history:
        with (run_dir / "training.csv").open("w", encoding="utf-8", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(history[0]))
            writer.writeheader()
            writer.writerows(history)
    print(json.dumps({"event": "finished", "stop_reason": stop_reason, "step": step, "elapsed_seconds": round(elapsed(), 1)}), flush=True)
    return {"stop_reason": stop_reason, "step": step, "elapsed_seconds": elapsed()}
