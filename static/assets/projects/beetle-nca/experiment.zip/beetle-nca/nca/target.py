from __future__ import annotations

import hashlib
import shutil
from collections import deque
from pathlib import Path

import numpy as np
from PIL import Image

from .common import rgba_image, write_json


def components(mask, minimum=1):
    """Connected components used to audit actual source features."""
    seen = np.zeros_like(mask, dtype=bool)
    result = []
    h, w = mask.shape
    for y, x in zip(*np.nonzero(mask)):
        if seen[y, x]:
            continue
        queue = deque([(int(y), int(x))])
        seen[y, x] = True
        pixels = []
        while queue:
            yy, xx = queue.popleft()
            pixels.append((yy, xx))
            for dy, dx in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                ny, nx = yy + dy, xx + dx
                if 0 <= ny < h and 0 <= nx < w and mask[ny, nx] and not seen[ny, nx]:
                    seen[ny, nx] = True
                    queue.append((ny, nx))
        if len(pixels) >= minimum:
            p = np.asarray(pixels)
            result.append({"pixels": len(pixels), "bbox_xyxy": [int(p[:, 1].min()), int(p[:, 0].min()), int(p[:, 1].max() + 1), int(p[:, 0].max() + 1)]})
    return result


def prepare(source, destination):
    source, destination = Path(source), Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    preserved = destination / "original.png"
    if source.resolve() != preserved.resolve():
        shutil.copy2(source, preserved)
    rgb8 = np.asarray(Image.open(preserved).convert("RGB"))
    rgb = rgb8.astype(np.float32) / 255
    alpha = np.clip((rgb8.max(axis=2).astype(np.float32) - 16) / 8, 0, 1)
    y, x = np.nonzero(alpha > 0)
    if len(x) == 0:
        raise ValueError("The image contains no foreground above the background threshold.")
    bbox = [int(x.min()), int(y.min()), int(x.max() + 1), int(y.max() + 1)]
    x0, y0, x1, y1 = bbox
    crop_rgb, crop_a = rgb[y0:y1, x0:x1], alpha[y0:y1, x0:x1]
    crop = np.concatenate([crop_rgb * crop_a[..., None], crop_a[..., None]], axis=-1)
    factor = 64 / max(crop.shape[:2])
    new_w, new_h = round(crop.shape[1] * factor), round(crop.shape[0] * factor)
    small = np.stack([np.asarray(Image.fromarray(crop[..., channel]).resize((new_w, new_h), Image.Resampling.BOX)) for channel in range(4)], -1)
    target = np.zeros((96, 96, 4), np.float32)
    ox, oy = (96 - new_w) // 2, (96 - new_h) // 2
    target[oy:oy + new_h, ox:ox + new_w] = small
    np.save(destination / "target.npy", target)
    straight = target.copy()
    straight[..., :3] = np.divide(straight[..., :3], straight[..., 3:4], out=np.zeros_like(straight[..., :3]), where=straight[..., 3:4] > 0)
    Image.fromarray(np.rint(straight.clip(0, 1) * 255).astype(np.uint8)).save(destination / "target.png")
    rgba_image(target, 6).save(destination / "target-preview.png")

    red = (rgb8[..., 0] > 120) & (rgb8[..., 1] < rgb8[..., 0] * 0.4) & (rgb8[..., 2] < rgb8[..., 0] * 0.4)
    features = components(red, minimum=40)
    small_red = (target[..., 0] > 0.3) & (target[..., 1] < target[..., 0] * 0.5) & (target[..., 2] < target[..., 0] * 0.5)
    for feature in features:
        fx0, fy0, fx1, fy1 = feature["bbox_xyxy"]
        tx0 = max(0, int(np.floor((fx0 - x0) * new_w / (x1 - x0))) + ox - 1)
        tx1 = min(96, int(np.ceil((fx1 - x0) * new_w / (x1 - x0))) + ox + 1)
        ty0 = max(0, int(np.floor((fy0 - y0) * new_h / (y1 - y0))) + oy - 1)
        ty1 = min(96, int(np.ceil((fy1 - y0) * new_h / (y1 - y0))) + oy + 1)
        feature["retained"] = bool(small_red[ty0:ty1, tx0:tx1].any())
        feature["target_bbox_xyxy"] = [tx0, ty0, tx1, ty1]
    structural = components(alpha >= 0.5, minimum=200)
    for feature in structural:
        fx0, fy0, fx1, fy1 = feature["bbox_xyxy"]
        tx0, ty0 = max(0, int((fx0-x0)*factor)+ox-1), max(0, int((fy0-y0)*factor)+oy-1)
        tx1, ty1 = min(96, int(np.ceil((fx1-x0)*factor))+ox+1), min(96, int(np.ceil((fy1-y0)*factor))+oy+1)
        feature["retained"] = bool((target[ty0:ty1, tx0:tx1, 3] >= 0.5).any())
    metadata = {"source_sha256": hashlib.sha256(preserved.read_bytes()).hexdigest(), "source_size_wh": [rgb.shape[1], rgb.shape[0]], "source_crop_xyxy": bbox, "resized_wh": [new_w, new_h], "grid_wh": [96, 96], "offset_xy": [ox, oy], "background_thresholds": [16, 24], "color_space": "sRGB values; RGB premultiplied by alpha; float32", "resampling": "area / Pillow BOX", "red_features": features, "structural_components": structural, "all_features_retained": all(f["retained"] for f in features + structural)}
    write_json(destination / "target-metadata.json", metadata)
    if not metadata["all_features_retained"]:
        raise ValueError("Some source features disappeared during preprocessing; inspect the saved audit.")
    return metadata


def load_target(path, device="cpu"):
    import torch
    array = np.load(path, allow_pickle=False)
    if array.shape != (96, 96, 4) or not np.isfinite(array).all():
        raise ValueError("Expected a finite, premultiplied RGBA 96 x 96 x 4 target array.")
    return torch.from_numpy(array).permute(2, 0, 1)[None].to(device=device)
