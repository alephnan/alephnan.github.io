from __future__ import annotations

import json
import os
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageDraw


BACKGROUND = np.array([10, 10, 12], dtype=np.float32) / 255


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def atomic_checkpoint(path, payload):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(payload, temporary)
    os.replace(temporary, path)


def load_checkpoint(path, map_location="cpu"):
    # Checkpoints are generated locally by this experiment, including RNG state.
    return torch.load(path, map_location=map_location, weights_only=False)


def rgba_image(rgba, scale=1):
    rgba = np.asarray(rgba, dtype=np.float32)
    alpha = rgba[..., 3:4].clip(0, 1)
    rgb = (rgba[..., :3] + BACKGROUND * (1 - alpha)).clip(0, 1)
    result = Image.fromarray(np.rint(rgb * 255).astype(np.uint8))
    if scale != 1:
        result = result.resize((result.width * scale, result.height * scale), Image.Resampling.NEAREST)
    return result


def state_rgba(state):
    return state[:, :4].detach().cpu().permute(0, 2, 3, 1).numpy()


def labeled_panel(images, labels, footer="", cell_scale=4):
    rendered = [rgba_image(im, cell_scale) for im in images]
    width = sum(im.width for im in rendered) + 16 * (len(images) + 1)
    height = max(im.height for im in rendered) + 78
    out = Image.new("RGB", (width, height), (10, 10, 12))
    draw = ImageDraw.Draw(out)
    x = 16
    for im, label in zip(rendered, labels):
        draw.text((x, 12), label, fill=(220, 221, 226))
        out.paste(im, (x, 34))
        x += im.width + 16
    draw.text((16, height - 25), footer, fill=(163, 166, 178))
    return out


def batch_metrics(state, target):
    pred = state[:, :4]
    target_mask = target[:, 3] >= 0.5
    mask = pred[:, 3] >= 0.5
    intersection = (mask & target_mask).sum((1, 2))
    union = (mask | target_mask).sum((1, 2)).clamp_min(1)
    iou = intersection.float() / union
    mse = ((pred - target) ** 2).mean((1, 2, 3))
    foreground = (target[:, 3:4] > 0.1).expand_as(pred)
    fg_mse = (((pred - target) ** 2) * foreground).sum((1, 2, 3)) / foreground.sum((1, 2, 3)).clamp_min(1)
    return {"iou": iou, "rgba_mse": mse, "foreground_rgba_mse": fg_mse}


def device_setup(device="cuda"):
    if device.startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError("CUDA is unavailable. Install the documented CUDA 12.6 PyTorch wheel; GPU training will not silently fall back to CPU.")
    torch.set_num_threads(4)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cudnn.benchmark = False
    return torch.device(device)
