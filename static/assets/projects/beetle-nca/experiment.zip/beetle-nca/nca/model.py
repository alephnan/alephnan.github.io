from __future__ import annotations

import torch
from torch import Tensor, nn
from torch.nn import functional as F


CHANNELS = 16
HIDDEN = 128
FIRE_RATE = 0.5
ALIVE_THRESHOLD = 0.1


def make_seed(batch: int = 1, size: int = 96, device="cpu") -> Tensor:
    state = torch.zeros(batch, CHANNELS, size, size, device=device)
    state[:, 3:, size // 2, size // 2] = 1.0
    return state


def living_mask(state: Tensor) -> Tensor:
    return F.max_pool2d(state[:, 3:4], 3, stride=1, padding=1) > ALIVE_THRESHOLD


class NCA(nn.Module):
    """48 -> 128 -> 16 local rule with exactly 8,336 trainable parameters.

    State is NCHW. Perception order is [state[0:16], dx[0:16], dy[0:16]].
    Kernels use cross-correlation, x rightward and y downward.
    """

    def __init__(self):
        super().__init__()
        identity = torch.zeros(3, 3)
        identity[1, 1] = 1
        dx = torch.tensor([[-1., 0., 1.], [-2., 0., 2.], [-1., 0., 1.]]) / 8
        kernels = torch.stack([identity, dx, dx.T])[:, None]
        self.register_buffer("perception_kernel", kernels.repeat(CHANNELS, 1, 1, 1))
        self.fc1 = nn.Conv2d(CHANNELS * 3, HIDDEN, 1, bias=True)
        self.fc2 = nn.Conv2d(HIDDEN, CHANNELS, 1, bias=True)
        nn.init.zeros_(self.fc2.weight)
        nn.init.zeros_(self.fc2.bias)

    def perceive(self, state: Tensor) -> Tensor:
        b, _, h, w = state.shape
        interleaved = F.conv2d(state, self.perception_kernel, padding=1, groups=CHANNELS)
        return interleaved.reshape(b, CHANNELS, 3, h, w).transpose(1, 2).reshape(b, 48, h, w)

    def forward(self, state: Tensor, update_mask: Tensor | None = None) -> Tensor:
        pre_alive = living_mask(state)
        delta = self.fc2(F.relu(self.fc1(self.perceive(state))))
        if update_mask is None:
            update_mask = torch.rand_like(state[:, :1]) < FIRE_RATE
        candidate = state + delta * update_mask
        return candidate * (pre_alive & living_mask(candidate))


@torch.no_grad()
def evolve(model: NCA, state: Tensor, steps: int, generator=None) -> Tensor:
    for _ in range(steps):
        mask = torch.rand(state.shape[0], 1, state.shape[2], state.shape[3],
                          device=state.device, generator=generator) < FIRE_RATE
        state = model(state, mask)
    return state
