from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
import torch

from .common import load_checkpoint, write_json
from .model import NCA


def numpy_step(state, weights, update_mask):
    """Independent NumPy reference. Inputs/outputs NCHW; no torch operations."""
    x = np.asarray(state, dtype=np.float32).transpose(0, 2, 3, 1)
    _, h, w, _ = x.shape
    padded = np.pad(x, ((0, 0), (1, 1), (1, 1), (0, 0)))
    dx = ((padded[:, :h, 2:w+2] + 2 * padded[:, 1:h+1, 2:w+2] + padded[:, 2:h+2, 2:w+2]) - (padded[:, :h, :w] + 2 * padded[:, 1:h+1, :w] + padded[:, 2:h+2, :w])) / 8
    dy = ((padded[:, 2:h+2, :w] + 2 * padded[:, 2:h+2, 1:w+1] + padded[:, 2:h+2, 2:w+2]) - (padded[:, :h, :w] + 2 * padded[:, :h, 1:w+1] + padded[:, :h, 2:w+2])) / 8
    perception = np.concatenate([x, dx, dy], axis=-1)
    hidden = np.maximum(perception @ weights["fc1.weight"].T + weights["fc1.bias"], 0)
    delta = hidden @ weights["fc2.weight"].T + weights["fc2.bias"]
    candidate = x + delta * np.asarray(update_mask).transpose(0, 2, 3, 1)

    def alive(value):
        alpha = np.pad(value[..., 3], ((0, 0), (1, 1), (1, 1)))
        return np.maximum.reduce([alpha[:, oy:oy+h, ox:ox+w] for oy in range(3) for ox in range(3)]) > 0.1

    result = candidate * (alive(x) & alive(candidate))[..., None]
    return np.ascontiguousarray(result.transpose(0, 3, 1, 2), dtype=np.float32)


def model_weights(model):
    return {name: p.detach().cpu().numpy().reshape(p.shape[:2] if p.ndim == 4 else p.shape).copy() for name, p in model.named_parameters()}


def read_export(directory):
    directory = Path(directory)
    manifest = json.loads((directory / "model.json").read_text(encoding="utf-8"))
    raw = (directory / "weights.f32").read_bytes()
    if hashlib.sha256(raw).hexdigest() != manifest["weights_sha256"]:
        raise ValueError("Export weight checksum mismatch")
    weights = {}
    for tensor in manifest["tensors"]:
        weights[tensor["name"]] = np.frombuffer(raw, dtype="<f4", count=tensor["elements"], offset=tensor["byte_offset"]).reshape(tensor["shape"])
    return manifest, weights


def export(checkpoint, destination):
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    payload = load_checkpoint(checkpoint)
    model = NCA().eval()
    model.load_state_dict(payload["model"])
    weights = model_weights(model)
    tensors, blocks, offset = [], [], 0
    for name, array in weights.items():
        data = np.asarray(array, dtype="<f4").tobytes(order="C")
        tensors.append({"name": name, "shape": list(array.shape), "elements": array.size, "byte_offset": offset, "byte_length": len(data), "layout": "output channel, input channel" if array.ndim == 2 else "output channel"})
        offset += len(data)
        blocks.append(data)
    raw = b"".join(blocks)
    (destination / "weights.f32").write_bytes(raw)
    manifest = {
        "format": "beetle-nca", "version": 1, "dtype": "float32", "byte_order": "little", "weights_file": "weights.f32", "weights_sha256": hashlib.sha256(raw).hexdigest(), "trainable_parameters": 8336,
        "checkpoint_step": payload["step"], "training_seed": payload["config"]["seed"], "target_sha256": payload.get("target_sha256"), "tensors": tensors,
        "state": {"channels": 16, "order": ["R_premultiplied", "G_premultiplied", "B_premultiplied", "alpha"] + [f"hidden_{i}" for i in range(12)], "reference_layout": "NCHW", "training_grid_wh": [96, 96], "precision": "float32", "clamp_recurrent_state": False},
        "perception": {"order": ["state channels 0..15", "dx channels 0..15", "dy channels 0..15"], "operation": "cross-correlation", "dx_kernel": [[-0.125, 0, 0.125], [-0.25, 0, 0.25], [-0.125, 0, 0.125]], "dy_kernel": [[-0.125, -0.25, -0.125], [0, 0, 0], [0.125, 0.25, 0.125]], "x_direction": "right", "y_direction": "down", "padding": "zero outside the grid"},
        "update": {"hidden_activation": "ReLU", "output_activation": "none", "residual_step_size": 1.0, "fire_rate": 0.5, "random_mask": "Independent Bernoulli per cell and step, shared across all 16 channels", "alive": "3x3 maximum alpha > 0.1", "sequence": ["compute pre_alive from old state", "compute perception and dense update", "candidate = state + update * random_mask", "compute post_alive from candidate", "next_state = candidate * (pre_alive AND post_alive)"]},
        "seed": {"position": "center cell", "rgb": [0, 0, 0], "alpha_and_hidden": 1, "all_other_cells": 0},
        "damage": "Set all 16 channels to zero inside an erase mask; never automatically reseed.",
        "render": "Clamp alpha for display only. Composite premultiplied RGB + background * (1-alpha); clamp displayed RGB to [0,1].",
    }
    write_json(destination / "model.json", manifest)
    _, decoded = read_export(destination)
    rng = np.random.default_rng(2026)
    state = rng.normal(0, 0.15, (1, 16, 12, 14)).astype(np.float32)
    state[:, 3] = np.where(rng.random((1, 12, 14)) > 0.55, 0.8, 0).astype(np.float32)
    state[:, :, :4, :4] = 0
    mask = rng.random((1, 1, 12, 14)) < 0.5
    with torch.no_grad():
        expected = model(torch.from_numpy(state), torch.from_numpy(mask)).numpy()
    actual = numpy_step(state, decoded, mask)
    max_error = float(np.max(np.abs(expected - actual)))
    if not np.allclose(expected, actual, rtol=1e-5, atol=1e-5):
        raise AssertionError(f"Export parity failed, max absolute error {max_error}")
    np.savez(destination / "parity-fixture.npz", state=state, update_mask=mask, expected=expected)
    for name, array, dtype in [("fixture-state.f32", state, "<f4"), ("fixture-mask.u8", mask, "u1"), ("fixture-expected.f32", expected, "<f4")]:
        (destination / name).write_bytes(np.asarray(array, dtype=dtype).tobytes(order="C"))
    parity = {"passed": True, "max_absolute_error": max_error, "rtol": 1e-5, "atol": 1e-5, "fixture_layout": "NCHW; C order; little-endian float32 except uint8 mask", "state_shape": list(state.shape), "mask_shape": list(mask.shape), "files": ["fixture-state.f32", "fixture-mask.u8", "fixture-expected.f32"]}
    write_json(destination / "parity.json", parity)
    return {"weights_bytes": len(raw), "parameters": 8336, "parity": parity}
