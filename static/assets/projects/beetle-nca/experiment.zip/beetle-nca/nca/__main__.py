from __future__ import annotations

import argparse
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description="Train, evaluate, and export the 8,336-parameter beetle NCA.")
    commands = parser.add_subparsers(dest="command", required=True)
    prep = commands.add_parser("prepare", help="Preserve the source image and prepare/audit the training target.")
    prep.add_argument("source", type=Path)
    prep.add_argument("--out", type=Path, default=ROOT / "assets")
    training = commands.add_parser("train", help="Train on the local GPU with a cumulative time budget.")
    training.add_argument("--target", type=Path, default=ROOT / "assets" / "target.npy")
    training.add_argument("--run-dir", type=Path, default=ROOT / "checkpoints")
    training.add_argument("--resume", type=Path)
    training.add_argument("--device", default="cuda")
    training.add_argument("--max-minutes", type=float, default=120)
    training.add_argument("--max-steps", type=int, help="Optional total-update limit for a short benchmark.")
    training.add_argument("--skip-validation", action="store_true", help="Only for a short benchmark; final evaluation remains separate.")
    evaluation = commands.add_parser("evaluate", help="Run the 16-seed held-out evaluation and damage/stability tests.")
    evaluation.add_argument("--checkpoint", type=Path, default=ROOT / "checkpoints" / "best.pt")
    evaluation.add_argument("--target", type=Path, default=ROOT / "assets" / "target.npy")
    evaluation.add_argument("--out", type=Path, default=ROOT / "results")
    evaluation.add_argument("--device", default="cuda")
    evaluation.add_argument("--base-seed", type=int, default=20000, help="First of 16 independent growth seeds; reserve a fresh range after refinement.")
    exporting = commands.add_parser("export", help="Export float32 weights, JSON metadata, and parity fixtures.")
    exporting.add_argument("--checkpoint", type=Path, default=ROOT / "checkpoints" / "best.pt")
    exporting.add_argument("--out", type=Path, default=ROOT / "export")
    rendering = commands.add_parser("render", help="Render actual growth/repair inference as GIF and MP4.")
    rendering.add_argument("--checkpoint", type=Path, default=ROOT / "checkpoints" / "best.pt")
    rendering.add_argument("--target", type=Path, default=ROOT / "assets" / "target.npy")
    rendering.add_argument("--out", type=Path, default=ROOT / "results")
    rendering.add_argument("--run-dir", type=Path, default=ROOT / "checkpoints")
    rendering.add_argument("--device", default="cuda")
    args = parser.parse_args()
    if args.command == "prepare":
        from .target import prepare
        result = prepare(args.source, args.out)
        result = {"resized_wh": result["resized_wh"], "grid_wh": result["grid_wh"], "red_features": len(result["red_features"]), "structural_components": len(result["structural_components"]), "all_features_retained": result["all_features_retained"]}
    elif args.command == "train":
        from .train import train
        result = train(args.target, args.run_dir, args.resume, args.device, args.max_minutes, args.max_steps, not args.skip_validation)
    elif args.command == "evaluate":
        from .evaluate import evaluate
        result = evaluate(args.checkpoint, args.target, args.out, args.device, args.base_seed)
    elif args.command == "export":
        from .export import export
        result = export(args.checkpoint, args.out)
    else:
        from .media import render
        result = render(args.checkpoint, args.target, args.out, args.run_dir, args.device)
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
