from pathlib import Path

import numpy as np
import torch

from nca.common import atomic_checkpoint, load_checkpoint
from nca.damage import damage_mask
from nca.export import export, model_weights, numpy_step, read_export
from nca.model import NCA, make_seed
from nca.train import capture_rng, normalize_gradients, restore_rng, seed_all


torch.set_num_threads(2)


def test_empty_grid_cannot_spawn_even_with_learned_biases():
    model = NCA()
    with torch.no_grad():
        model.fc2.bias.fill_(1.0)
        state = torch.zeros(2, 16, 9, 11)
        for _ in range(12):
            state = model(state)
    assert torch.count_nonzero(state) == 0


def test_training_has_finite_nonzero_gradients():
    seed_all(7)
    model = NCA()
    state = make_seed(2, 13)
    target = torch.zeros(2, 4, 13, 13)
    target[:, 0, 4:9, 4:9] = 0.8
    target[:, 3, 4:9, 4:9] = 1.0
    for _ in range(5):
        state = model(state)
    ((state[:, :4] - target) ** 2).mean().backward()
    assert sum(p.numel() for p in model.parameters()) == 8336
    assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters())
    assert model.fc2.weight.grad.abs().sum() > 0
    assert normalize_gradients(model)


def test_numpy_parity_exercises_learned_updates_and_boundaries():
    seed_all(9)
    model = NCA().eval()
    with torch.no_grad():
        model.fc2.weight.normal_(0, 0.01)
        model.fc2.bias.normal_(0, 0.01)
    rng = np.random.default_rng(10)
    x = rng.normal(0, 0.2, (2, 16, 11, 13)).astype(np.float32)
    x[:, 3] = np.where(rng.random((2, 11, 13)) > 0.7, 0.8, 0)
    x[:, :, :4, :4] = 0
    expected, actual = torch.from_numpy(x.copy()), x.copy()
    weights = model_weights(model)
    with torch.no_grad():
        for _ in range(32):
            mask = rng.random((2, 1, 11, 13)) < 0.5
            expected = model(expected, torch.from_numpy(mask))
            actual = numpy_step(actual, weights, mask)
    np.testing.assert_allclose(actual, expected.numpy(), rtol=1e-5, atol=1e-5)


def test_checkpoint_restores_optimizer_pool_and_random_streams(tmp_path):
    seed_all(42)
    rng = np.random.default_rng(42)
    model = NCA()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.002)
    pool = make_seed(8, 11)
    target = torch.zeros(2, 4, 11, 11)
    target[:, 3, 3:8, 3:8] = 1

    def update(current_model, current_optimizer, current_pool, current_rng):
        ids = current_rng.choice(len(current_pool), 2, replace=False)
        state = current_pool[ids].clone()
        current_optimizer.zero_grad(set_to_none=True)
        for _ in range(int(current_rng.integers(3, 6))):
            state = current_model(state)
        loss = ((state[:, :4] - target) ** 2).mean()
        loss.backward()
        normalize_gradients(current_model)
        current_optimizer.step()
        current_pool[ids] = state.detach()
        return ids, float(loss.detach())

    update(model, optimizer, pool, rng)
    checkpoint = tmp_path / "resume.pt"
    atomic_checkpoint(checkpoint, {"model": model.state_dict(), "optimizer": optimizer.state_dict(), "pool": pool, "rng": capture_rng(rng)})
    expected_ids, expected_loss = update(model, optimizer, pool, rng)
    saved = load_checkpoint(checkpoint)
    resumed_model = NCA()
    resumed_model.load_state_dict(saved["model"])
    resumed_optimizer = torch.optim.Adam(resumed_model.parameters(), lr=0.002)
    resumed_optimizer.load_state_dict(saved["optimizer"])
    resumed_rng = np.random.default_rng()
    restore_rng(saved["rng"], resumed_rng)
    actual_ids, actual_loss = update(resumed_model, resumed_optimizer, saved["pool"], resumed_rng)
    np.testing.assert_array_equal(actual_ids, expected_ids)
    assert actual_loss == expected_loss
    torch.testing.assert_close(saved["pool"], pool, rtol=0, atol=0)
    for name, value in model.state_dict().items():
        torch.testing.assert_close(resumed_model.state_dict()[name], value, rtol=0, atol=0)


def test_export_binary_round_trip_and_fixture(tmp_path):
    seed_all(5)
    model = NCA()
    with torch.no_grad():
        model.fc2.weight.normal_(0, 0.01)
    checkpoint = tmp_path / "model.pt"
    atomic_checkpoint(checkpoint, {"model": model.state_dict(), "step": 17, "config": {"seed": 5}})
    result = export(checkpoint, tmp_path / "export")
    assert result["weights_bytes"] == 8336 * 4
    _, decoded = read_export(tmp_path / "export")
    for name, value in model_weights(model).items():
        np.testing.assert_array_equal(decoded[name], value)
    fixture = np.load(tmp_path / "export" / "parity-fixture.npz")
    np.testing.assert_allclose(numpy_step(fixture["state"], decoded, fixture["update_mask"]), fixture["expected"], rtol=1e-5, atol=1e-5)


def test_damage_is_partial_and_local_for_both_shapes():
    foreground = np.zeros((96, 96), bool)
    foreground[23:74, 33:64] = True
    foreground[40:55, 15:82] = True
    for kind in ["circle", "rectangle"]:
        for seed in range(16):
            mask, fraction = damage_mask(foreground, np.random.default_rng(seed), kind)
            assert 0.10 <= fraction <= 0.30
            assert np.any(foreground & ~mask)
            assert np.isclose(fraction, np.sum(mask & foreground) / foreground.sum())


def test_prepared_artwork_keeps_red_features_and_valid_premultiplication():
    import json
    assets = Path(__file__).resolve().parents[1] / "assets"
    target = np.load(assets / "target.npy")
    audit = json.loads((assets / "target-metadata.json").read_text(encoding="utf-8"))
    assert target.shape == (96, 96, 4)
    assert audit["all_features_retained"]
    assert len(audit["red_features"]) >= 10
    assert np.all(target[..., :3] <= target[..., 3:4] + 1e-6)
    assert np.count_nonzero(target[:16]) == 0
    assert np.count_nonzero(target[-16:]) == 0


def test_evaluation_reports_numeric_overflow_without_invalid_json():
    import json
    from nca.evaluate import evaluate_model

    class ExplodingRule(torch.nn.Module):
        def forward(self, state, mask):
            return state * 1.15

    target = torch.zeros(1, 4, 7, 7)
    report, tensors = evaluate_model(ExplodingRule(), target, count=1, full=False)
    assert not report["acceptance_passed"]
    assert report["error"] == "Non-finite state or squared error during growth"
    assert tensors is None
    json.dumps(report, allow_nan=False)
